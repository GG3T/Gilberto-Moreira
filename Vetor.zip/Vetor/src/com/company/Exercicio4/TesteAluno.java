package com.company.Exercicio4;

public class TesteAluno {

    public static void main(String[] args){

        Aluno[] a = new Aluno[3];
        a[0] = new Aluno("João", 20);
        a[1] = new Aluno("Maria", 21);
        a[2] = new Aluno("Pedro", 22);

        
    }
}
