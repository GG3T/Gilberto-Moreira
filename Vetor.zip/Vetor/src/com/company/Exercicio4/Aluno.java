package com.company.Exercicio4;

public class Aluno {

    private String nome;
    private int rm;

    public Aluno(String nome, int rm) {
        this.nome = nome;
        this.rm = rm;
    }
}
