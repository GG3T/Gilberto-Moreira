package com.company;

public class Main {

    public static void main(String[] args) {
	int[] x = {1,2,3};
	double[] y = {0.5, 1.75, 2.5};
	String[] z = {"patricia", "selmini", "parducci"};

	imprimir(y, z, x);

    }

    public static void imprimir(double[] y, String[] z, int[] x){
        for (double i : y ){
            System.out.println("Imprimindo Valores de Y: " + i);
        }
        for (String i : z ){
            System.out.println("Imprimindo Valores de Z: " + i);
    }
        for (int i : x ){
            System.out.println("Imprimindo Valores de X: " + i);
        }
    }
}
