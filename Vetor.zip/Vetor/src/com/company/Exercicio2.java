package com.company;

public class Exercicio2 {
    public static void main(String[] args){
        imprimir(2,4);
        imprimir(3,4,5);
        imprimir(1,2,3,4,5,6);
    }

    private static void imprimir(int ...x) {
        for (int i: x ) {
            System.out.println(i);
        }
    }

}
